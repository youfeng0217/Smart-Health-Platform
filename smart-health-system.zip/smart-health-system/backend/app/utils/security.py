import jwt
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
from flask import request, current_app
from app.utils.response import error_response
from functools import wraps

# 密码加密（核心修正点）
def encrypt_password(password):
    # 修正：method改为合法的 pbkdf2:sha256，也可以直接省略method参数（默认就是pbkdf2:sha256）
    return generate_password_hash(password, method="pbkdf2:sha256")

# 密码校验
def verify_password(hashed_pwd, raw_pwd):
    return check_password_hash(hashed_pwd, raw_pwd)

# 生成JWT Token
def generate_token(user_id):
    payload = {
        "user_id": user_id,
        "exp": datetime.now() + timedelta(days=7) # Token有效期7天
    }
    token = jwt.encode(payload, current_app.config["SECRET_KEY"], algorithm="HS256")
    return token

# 解析JWT Token
def parse_token(token):
    try:
        payload = jwt.decode(token, current_app.config["SECRET_KEY"], algorithms=["HS256"])
        return payload["user_id"]
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

# 登录鉴权装饰器
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # 从请求头获取Token
        token = request.headers.get("Authorization")
        if not token:
            return error_response(message="请先登录", code=401)
        # 去除Bearer前缀
        if token.startswith("Bearer "):
            token = token[7:]
        # 解析Token
        user_id = parse_token(token)
        if not user_id:
            return error_response(message="Token无效或已过期", code=401)
        # 将用户ID传入视图函数
        kwargs["current_user_id"] = user_id
        return f(*args, **kwargs)
    return decorated_function
