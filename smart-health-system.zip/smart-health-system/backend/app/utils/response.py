from flask import jsonify

def success_response(data=None, message="操作成功", code=200):
    """成功响应统一格式"""
    response = {
        "code": code,
        "message": message,
        "data": data if data is not None else {}
    }
    return jsonify(response), code

def error_response(message="操作失败", code=400):
    """失败响应统一格式"""
    response = {
        "code": code,
        "message": message,
        "data": {}
    }
    return jsonify(response), code