import re

def desensitize_text(text):
    """对文本中的敏感信息进行脱敏"""
    # 身份证号脱敏
    text = re.sub(r'(\d{6})\d{8}(\d{4})', r'\1********\2', text)
    # 手机号脱敏
    text = re.sub(r'1[3-9]\d{9}', lambda m: m.group()[:3] + '****' + m.group()[-4:], text)
    # 姓名脱敏
    text = re.sub(r'([\u4e00-\u9fa5]{1})([\u4e00-\u9fa5]+)', r'\1*', text)
    # 地址脱敏
    text = re.sub(r'([\u4e00-\u9fa5]+省|市|区|县).*?(号|室)', r'\1***\2', text)
    return text

def desensitize_dataframe(df):
    """对DataFrame表格数据进行脱敏"""
    for col in df.columns:
        if df[col].dtype == object:
            df[col] = df[col].astype(str).apply(desensitize_text)
    return df