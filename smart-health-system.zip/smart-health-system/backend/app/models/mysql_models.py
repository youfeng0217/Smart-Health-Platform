from app import db
from datetime import datetime

# 1. 用户信息表
class User(db.Model):
    __tablename__ = "user_info"
    user_id = db.Column(db.Integer, primary_key=True, autoincrement=True, comment="用户ID")
    username = db.Column(db.String(50), nullable=False, unique=True, comment="用户名")
    password_hash = db.Column(db.String(255), nullable=False, comment="密码哈希值")
    email = db.Column(db.String(100), unique=True, comment="邮箱")
    phone = db.Column(db.String(20), comment="手机号")
    role = db.Column(db.String(20), default="user", comment="角色：user/admin")
    create_time = db.Column(db.DateTime, default=datetime.now, comment="创建时间")
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now, comment="更新时间")

# 2. 健康数据表（元数据）
class HealthData(db.Model):
    __tablename__ = "health_data"
    data_id = db.Column(db.Integer, primary_key=True, autoincrement=True, comment="数据ID")
    user_id = db.Column(db.Integer, db.ForeignKey("user_info.user_id", ondelete="CASCADE"), nullable=False, comment="所属用户ID")
    data_type = db.Column(db.Enum("text", "image", "signal"), nullable=False, comment="数据类型")
    file_name = db.Column(db.String(255), nullable=False, comment="原始文件名")
    file_path = db.Column(db.String(500), nullable=False, comment="存储路径")
    file_size = db.Column(db.BigInteger, comment="文件大小（字节）")
    upload_time = db.Column(db.DateTime, default=datetime.now, comment="上传时间")
    is_desensitized = db.Column(db.Boolean, default=False, comment="是否已脱敏")
    # 关联关系
    user = db.relationship("User", backref=db.backref("health_data", lazy=True))

# 3. 影像数据表
class ImageData(db.Model):
    __tablename__ = "image_data"
    image_id = db.Column(db.Integer, primary_key=True, autoincrement=True, comment="影像ID")
    data_id = db.Column(db.Integer, db.ForeignKey("health_data.data_id", ondelete="CASCADE"), nullable=False, unique=True, comment="关联的健康数据ID")
    image_format = db.Column(db.String(10), comment="影像格式")
    resolution = db.Column(db.String(50), comment="分辨率")
    body_part = db.Column(db.String(50), comment="拍摄部位")
    # 关联关系
    health_data = db.relationship("HealthData", backref=db.backref("image_info", lazy=True, uselist=False))

# 4. 风险评估结果表
class RiskAssessment(db.Model):
    __tablename__ = "risk_assessment"
    assessment_id = db.Column(db.Integer, primary_key=True, autoincrement=True, comment="评估ID")
    user_id = db.Column(db.Integer, db.ForeignKey("user_info.user_id", ondelete="CASCADE"), nullable=False, comment="用户ID")
    data_ids = db.Column(db.Text, comment="关联的健康数据ID列表（JSON格式）")
    risk_level = db.Column(db.Enum("low", "medium", "high"), nullable=False, comment="风险等级")
    risk_score = db.Column(db.Float, comment="风险评分（0-100）")
    disease_type = db.Column(db.String(100), comment="预测疾病类型")
    assessment_time = db.Column(db.DateTime, default=datetime.now, comment="评估时间")
    algorithm_version = db.Column(db.String(50), comment="算法版本")
    # 关联关系
    user = db.relationship("User", backref=db.backref("assessment_records", lazy=True))

# 5. 算法参数表
class AlgorithmParam(db.Model):
    __tablename__ = "algorithm_params"
    param_id = db.Column(db.Integer, primary_key=True, autoincrement=True, comment="参数ID")
    param_name = db.Column(db.String(100), nullable=False, unique=True, comment="参数名称")
    param_value = db.Column(db.Text, comment="参数值（JSON格式）")
    description = db.Column(db.Text, comment="参数说明")
    update_time = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now, comment="更新时间")

# 6. 健康建议表
class HealthSuggestion(db.Model):
    __tablename__ = "health_suggestion"
    suggestion_id = db.Column(db.Integer, primary_key=True, autoincrement=True, comment="建议ID")
    risk_level = db.Column(db.Enum("low", "medium", "high"), nullable=False, comment="对应风险等级")
    disease_type = db.Column(db.String(100), comment="对应疾病类型")
    suggestion_content = db.Column(db.Text, nullable=False, comment="建议内容")
    source = db.Column(db.String(255), comment="建议来源（指南名称）")