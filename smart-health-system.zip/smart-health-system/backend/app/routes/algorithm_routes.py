from flask import Blueprint, request
from app.services.algorithm_service import AlgorithmService
from app.utils.security import login_required
from app.utils.response import error_response

algo_bp = Blueprint("algo_bp", __name__)
algo_service = AlgorithmService()

# 提交风险评估
@algo_bp.route("/assessment/submit", methods=["POST"])
@login_required
def submit_assessment(current_user_id):
    data = request.get_json()
    if not data.get("data_ids"):
        return error_response(message="请选择要分析的数据")
    return algo_service.multimodal_fusion(
        user_id=current_user_id,
        data_ids=data["data_ids"]
    )

# 获取评估记录
@algo_bp.route("/assessment/records", methods=["GET"])
@login_required
def get_records(current_user_id):
    return AlgorithmService.get_assessment_records(current_user_id)
