from flask import Blueprint, request
from app.services.user_service import UserService
from app.utils.security import login_required
from app.utils.response import error_response

user_bp = Blueprint("user_bp", __name__)

# 用户注册
@user_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    required_fields = ["username", "password", "email"]
    if not all(field in data for field in required_fields):
        return error_response(message="缺少必填参数")
    return UserService.register_user(
        username=data["username"],
        password=data["password"],
        email=data["email"],
        phone=data.get("phone")
    )

# 用户登录
@user_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    if not data.get("username") or not data.get("password"):
        return error_response(message="用户名和密码不能为空")
    return UserService.login_user(
        username=data["username"],
        password=data["password"]
    )

# 获取用户信息
@user_bp.route("/info", methods=["GET"])
@login_required
def get_info(current_user_id):
    return UserService.get_user_info(current_user_id)

# 更新用户信息
@user_bp.route("/update", methods=["PUT"])
@login_required
def update_info(current_user_id):
    data = request.get_json()
    return UserService.update_user_info(
        user_id=current_user_id,
        email=data.get("email"),
        phone=data.get("phone")
    )