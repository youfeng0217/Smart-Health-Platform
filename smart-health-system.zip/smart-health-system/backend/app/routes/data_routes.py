from flask import Blueprint, request
from app.services.data_service import DataService
from app.utils.security import login_required
from app.utils.response import error_response

data_bp = Blueprint("data_bp", __name__)

# 上传文件
@data_bp.route("/upload", methods=["POST"])
@login_required
def upload(current_user_id):
    if "file" not in request.files:
        return error_response(message="未上传文件")
    file = request.files["file"]
    data_type = request.form.get("data_type")
    if not data_type:
        return error_response(message="请指定数据类型")
    return DataService.upload_file(
        user_id=current_user_id,
        file=file,
        data_type=data_type,
        body_part=request.form.get("body_part")
    )

# 获取用户数据列表
@data_bp.route("/list", methods=["GET"])
@login_required
def get_list(current_user_id):
    data_type = request.args.get("data_type")
    return DataService.get_user_data_list(current_user_id, data_type)

# 删除数据
@data_bp.route("/delete/<int:data_id>", methods=["DELETE"])
@login_required
def delete(current_user_id, data_id):
    return DataService.delete_data(current_user_id, data_id)