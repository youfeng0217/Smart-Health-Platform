from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from app.config import Config
import os

# 初始化数据库ORM
db = SQLAlchemy()

def create_app(config_class=Config):
    # 创建Flask应用
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # 初始化插件
    CORS(app, supports_credentials=True) # 解决跨域
    db.init_app(app)
    
    # 创建上传目录
    if not os.path.exists(app.config["UPLOAD_FOLDER"]):
        os.makedirs(app.config["UPLOAD_FOLDER"])
        os.makedirs(os.path.join(app.config["UPLOAD_FOLDER"], "text"))
        os.makedirs(os.path.join(app.config["UPLOAD_FOLDER"], "image"))
        os.makedirs(os.path.join(app.config["UPLOAD_FOLDER"], "signal"))
    
    # 注册路由蓝图
    from app.routes.user_routes import user_bp
    from app.routes.data_routes import data_bp
    from app.routes.algorithm_routes import algo_bp
    
    app.register_blueprint(user_bp, url_prefix="/api/user")
    app.register_blueprint(data_bp, url_prefix="/api/data")
    app.register_blueprint(algo_bp, url_prefix="/api/algorithm")
    
    # 全局异常处理
    from app.utils.response import error_response
    @app.errorhandler(Exception)
    def handle_exception(e):
        return error_response(message=f"系统异常：{str(e)}", code=500)
    
    # 注册数据库模型
    with app.app_context():
        from app.models.mysql_models import User, HealthData, ImageData, RiskAssessment, AlgorithmParam, HealthSuggestion
        db.create_all() # 自动创建所有表
    
    return app
