import json
import numpy as np
import pandas as pd
import cv2
import jieba
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, Flatten, LSTM, Dropout, Input
from flask import current_app
from app import db
from app.models.mysql_models import HealthData, RiskAssessment, HealthSuggestion
from app.utils.response import success_response, error_response


class AlgorithmService:
    def __init__(self):
        self.version = "v1.0"
        self.scaler = StandardScaler()
        self.tfidf = TfidfVectorizer(max_features=100)
        # 初始化自编码器（特征融合）
        self.autoencoder = self._build_autoencoder(input_dim=300)
    
    def _build_autoencoder(self, input_dim):
        """构建单层自编码器（对应文档中的早期融合）"""
        model = Sequential([
            Input(shape=(input_dim,)),
            Dense(128, activation='relu'),
            Dense(64, activation='relu'),
            Dense(128, activation='relu'),
            Dense(input_dim, activation='sigmoid')
        ])
        model.compile(optimizer='adam', loss='mse')
        return model
    
    def _extract_text_feature(self, text_path):
        """提取文本特征（TF-IDF，对应文档中的病历文本处理）"""
        try:
            with open(text_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            # 分词
            words = " ".join(jieba.lcut(content))
            # TF-IDF特征提取
            feature = self.tfidf.fit_transform([words]).toarray()[0]
            # 统一维度到100维
            if len(feature) < 100:
                feature = np.pad(feature, (0, 100-len(feature)), mode='constant')
            return feature[:100]
        except Exception as e:
            return np.zeros(100)
    
    def _extract_image_feature(self, image_path):
        """提取影像特征（轻量CNN，对应文档中的医学影像处理）"""
        try:
            # 读取并预处理图片
            img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
            img = cv2.resize(img, (64, 64)) / 255.0
            img = np.expand_dims(img, axis=(0, -1))
            # 轻量CNN特征提取
            cnn_model = Sequential([
                Input(shape=(64,64,1)),
                Conv2D(16, (3,3), activation='relu'),
                Flatten(),
                Dense(100, activation='relu')
            ])
            feature = cnn_model.predict(img, verbose=0)[0]
            return feature
        except Exception as e:
            return np.zeros(100)
    
    def _extract_signal_feature(self, signal_path):
        """提取生理信号特征（LSTM，对应文档中的生理信号处理）"""
        try:
            df = pd.read_csv(signal_path)
            # 取数值列
            signal_data = df.select_dtypes(include=[np.number]).values
            # 统一长度
            if len(signal_data) > 100:
                signal_data = signal_data[:100]
            else:
                signal_data = np.pad(signal_data, ((0, 100-len(signal_data)), (0,0)), mode='constant')
            # LSTM特征提取
            lstm_model = Sequential([
                Input(shape=(signal_data.shape[0], signal_data.shape[1])),
                LSTM(64),
                Dense(100, activation='relu')
            ])
            feature = lstm_model.predict(np.expand_dims(signal_data, axis=0), verbose=0)[0]
            return feature
        except Exception as e:
            return np.zeros(100)
    
    def multimodal_fusion(self, user_id, data_ids):
        """多模态数据融合与风险评估（核心功能）"""
        # 获取用户上传的数据
        data_list = HealthData.query.filter(
            HealthData.user_id == user_id,
            HealthData.data_id.in_(data_ids)
        ).all()
        if not data_list:
            return error_response(message="未找到对应的数据")
        
        # 提取各模态特征
        features = []
        for data in data_list:
            if data.data_type == "text":
                features.append(self._extract_text_feature(data.file_path))
            elif data.data_type == "image":
                features.append(self._extract_image_feature(data.file_path))
            elif data.data_type == "signal":
                features.append(self._extract_signal_feature(data.file_path))
        
        # 特征拼接（早期融合，对应文档中的算法原型）
        concat_feature = np.concatenate(features)
        # 统一维度到300维
        if len(concat_feature) < 300:
            concat_feature = np.pad(concat_feature, (0, 300-len(concat_feature)), mode='constant')
        concat_feature = concat_feature[:300].reshape(1, -1)
        
        # 自编码器融合
        fused_feature = self.autoencoder.predict(concat_feature, verbose=0)[0]
        
        # 风险评分计算（简化版，可根据实际模型优化）
        risk_score = float(np.mean(fused_feature) * 100)
        # 风险等级划分
        if risk_score < 40:
            risk_level = "low"
        elif risk_score < 70:
            risk_level = "medium"
        else:
            risk_level = "high"
        
        # 疾病类型预测（简化版）
        disease_type = "高血压/糖尿病高风险" if risk_score >= 70 else "无明显慢性病高风险"
        
        # 保存评估结果到数据库
        new_assessment = RiskAssessment(
            user_id=user_id,
            data_ids=json.dumps(data_ids),
            risk_level=risk_level,
            risk_score=risk_score,
            disease_type=disease_type,
            algorithm_version=self.version
        )
        db.session.add(new_assessment)
        db.session.commit()
        
        # 获取健康建议
        suggestion = HealthSuggestion.query.filter_by(
            risk_level=risk_level,
            disease_type=disease_type
        ).first()
        suggestion_content = suggestion.suggestion_content if suggestion else "请保持健康的生活习惯，定期体检"
        
        return success_response(message="风险评估完成", data={
            "assessment_id": new_assessment.assessment_id,
            "risk_score": round(risk_score, 2),
            "risk_level": risk_level,
            "disease_type": disease_type,
            "suggestion": suggestion_content,
            "algorithm_version": self.version
        })
    
    @staticmethod
    def get_assessment_records(user_id):
        """获取用户的风险评估记录"""
        records = RiskAssessment.query.filter_by(user_id=user_id).order_by(RiskAssessment.assessment_time.desc()).all()
        result = []
        for record in records:
            result.append({
                "assessment_id": record.assessment_id,
                "risk_score": record.risk_score,
                "risk_level": record.risk_level,
                "disease_type": record.disease_type,
                "assessment_time": record.assessment_time.strftime("%Y-%m-%d %H:%M:%S"),
                "algorithm_version": record.algorithm_version
            })
        return success_response(data=result)
