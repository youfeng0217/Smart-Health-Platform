import os
import pandas as pd
from werkzeug.utils import secure_filename
from flask import current_app 
from app import db
from app.models.mysql_models import HealthData, ImageData
from app.utils.data_mask import desensitize_text, desensitize_dataframe
from app.utils.response import success_response, error_response

class DataService:
    @staticmethod
    def allowed_file(filename, data_type):
        """检查文件类型是否合法"""
        ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
        return ext in current_app.config["ALLOWED_EXTENSIONS"][data_type]
    
    @staticmethod
    def upload_file(user_id, file, data_type, body_part=None):
        # 校验文件
        if not file or file.filename == '':
            return error_response(message="未选择文件")
        if not DataService.allowed_file(file.filename, data_type):
            return error_response(message="不支持的文件类型")
        
        # 安全处理文件名
        filename = secure_filename(file.filename)
        # 生成存储路径
        save_dir = os.path.join(current_app.config["UPLOAD_FOLDER"], data_type)
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        file_path = os.path.join(save_dir, filename)
        # 保存文件
        file.save(file_path)
        file_size = os.path.getsize(file_path)
        
        # 数据脱敏处理
        is_desensitized = False
        try:
            if data_type == "text":
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                desensitized_content = desensitize_text(content)
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(desensitized_content)
                is_desensitized = True
            elif data_type == "signal":
                if filename.endswith('.csv'):
                    df = pd.read_csv(file_path)
                    df = desensitize_dataframe(df)
                    df.to_csv(file_path, index=False)
                    is_desensitized = True
        except Exception as e:
            print(f"脱敏处理警告: {e}")
        
        # 保存元数据到数据库
        new_data = HealthData(
            user_id=user_id,
            data_type=data_type,
            file_name=filename,
            file_path=file_path,
            file_size=file_size,
            is_desensitized=is_desensitized
        )
        db.session.add(new_data)
        db.session.flush() # 获取自增的data_id
        
        # 影像数据补充信息
        if data_type == "image":
            try:
                import cv2
                img = cv2.imread(file_path)
                if img is not None:
                    height, width = img.shape[:2]
                    new_image = ImageData(
                        data_id=new_data.data_id,
                        image_format=filename.rsplit('.', 1)[1].lower(),
                        resolution=f"{width}x{height}",
                        body_part=body_part if body_part else "未知"
                    )
                    db.session.add(new_image)
            except Exception as e:
                print(f"影像信息提取警告: {e}")
        
        db.session.commit()
        return success_response(message="文件上传成功", data={
            "data_id": new_data.data_id,
            "file_name": filename,
            "is_desensitized": is_desensitized
        })
    
    @staticmethod
    def get_user_data_list(user_id, data_type=None):
        """获取用户上传的数据列表"""
        query = HealthData.query.filter_by(user_id=user_id)
        if data_type:
            query = query.filter_by(data_type=data_type)
        data_list = query.order_by(HealthData.upload_time.desc()).all()
        
        result = []
        for data in data_list:
            result.append({
                "data_id": data.data_id,
                "data_type": data.data_type,
                "file_name": data.file_name,
                "file_size": f"{round(data.file_size/1024, 2)}KB" if data.file_size else "0KB",
                "upload_time": data.upload_time.strftime("%Y-%m-%d %H:%M:%S"),
                "is_desensitized": data.is_desensitized
            })
        return success_response(data=result)
    
    @staticmethod
    def delete_data(user_id, data_id):
        """删除用户上传的数据"""
        data = HealthData.query.filter_by(data_id=data_id, user_id=user_id).first()
        if not data:
            return error_response(message="数据不存在或无权限删除")
        # 删除本地文件
        try:
            if os.path.exists(data.file_path):
                os.remove(data.file_path)
        except Exception as e:
            print(f"删除文件警告: {e}")
        # 删除数据库记录
        db.session.delete(data)
        db.session.commit()
        return success_response(message="删除成功")
