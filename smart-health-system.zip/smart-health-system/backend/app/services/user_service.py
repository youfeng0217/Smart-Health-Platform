from app import db
from app.models.mysql_models import User
from app.utils.security import encrypt_password, verify_password, generate_token
from app.utils.response import error_response, success_response

class UserService:
    @staticmethod
    def register_user(username, password, email, phone=None):
        # 检查用户名是否存在
        if User.query.filter_by(username=username).first():
            return error_response(message="用户名已存在")
        # 检查邮箱是否存在
        if User.query.filter_by(email=email).first():
            return error_response(message="邮箱已被注册")
        # 创建用户
        hashed_pwd = encrypt_password(password)
        new_user = User(
            username=username,
            password_hash=hashed_pwd,
            email=email,
            phone=phone
        )
        db.session.add(new_user)
        db.session.commit()
        return success_response(message="注册成功", data={"user_id": new_user.user_id})
    
    @staticmethod
    def login_user(username, password):
        # 查询用户
        user = User.query.filter_by(username=username).first()
        if not user:
            return error_response(message="用户不存在")
        # 校验密码
        if not verify_password(user.password_hash, password):
            return error_response(message="密码错误")
        # 生成Token
        token = generate_token(user.user_id)
        return success_response(message="登录成功", data={
            "token": token,
            "user_id": user.user_id,
            "username": user.username,
            "role": user.role
        })
    
    @staticmethod
    def get_user_info(user_id):
        user = User.query.get(user_id)
        if not user:
            return error_response(message="用户不存在")
        return success_response(data={
            "user_id": user.user_id,
            "username": user.username,
            "email": user.email,
            "phone": user.phone,
            "create_time": user.create_time.strftime("%Y-%m-%d %H:%M:%S")
        })
    
    @staticmethod
    def update_user_info(user_id, email=None, phone=None):
        user = User.query.get(user_id)
        if not user:
            return error_response(message="用户不存在")
        if email:
            user.email = email
        if phone:
            user.phone = phone
        db.session.commit()
        return success_response(message="信息更新成功")
