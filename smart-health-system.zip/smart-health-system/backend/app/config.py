import os
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

class Config:
    # 基础配置
    SECRET_KEY = os.getenv("SECRET_KEY")
    UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER")
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_CONTENT_LENGTH"))
    
    # 数据库配置
    SQLALCHEMY_DATABASE_URI = os.getenv("MYSQL_URI")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = True # 开发环境打印SQL语句
    
    # 允许的文件类型
    ALLOWED_EXTENSIONS = {
        "text": ["txt", "csv", "doc", "docx"],
        "image": ["png", "jpg", "jpeg", "dcm"],
        "signal": ["csv", "xlsx", "mat"]
    }